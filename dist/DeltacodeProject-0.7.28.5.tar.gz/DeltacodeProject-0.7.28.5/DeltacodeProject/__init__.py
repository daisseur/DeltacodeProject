# __init__.py
"""
A venir...
"""

__title__ = "DeltacodeProject"
__version__ = "0.7.28.5"

